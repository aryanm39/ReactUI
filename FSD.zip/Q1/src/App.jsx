import { useState } from 'react'
import './App.css'

function App() {

  return (
    <>
      
      <div style={{float : 'left'}}>
        <img style={{width : '300px', height : '300px', marginRight : '40px'}} src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="profile" />
      </div>
      <div style={{float : 'left'}}>
        <h3>Name : Hemant Ganesh Kshirsagar</h3>
        <h5>this is short bio</h5>
      </div>

    </>
  )
}

export default App
